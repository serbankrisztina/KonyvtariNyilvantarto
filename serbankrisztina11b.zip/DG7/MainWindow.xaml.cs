﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace DG7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> vegyeslist = new List<string>();
        List<Patient> _list;
        int t2 = 0;
        int kv = 0;
        int ks = 0;
        int id = 0;
        int selectedindexszam = 0;
        public MainWindow()
        {
            InitializeComponent();  
        }

        private void DataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            var patients = new List<Patient>();
            using (StreamReader reader = new StreamReader("tagok.txt"))
            {
                while (true)
                {
                    string line = reader.ReadLine();
                    if (line == null)
                    {
                        break;
                    }
                    patients.Add(new Patient(line));
                }
            }
            this._list = patients;
            var grid = sender as DataGrid;
            grid.ItemsSource = patients;
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(dgUsers.ItemsSource);
            view.Filter = UserFilter;

            var mogyoró = File.ReadAllLines(@"tagok.txt");
            tagokszama.Text = Convert.ToString(mogyoró.Length);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            using (StreamWriter writer = new StreamWriter("tagok.txt"))
            {
                foreach (Patient patient in this._list)
                {
                    writer.WriteLine(patient.GetLine());
                }
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            txtFilter.Text = "";
            try
            {
                Könyvek.Text = "";
                vegyeslist.Clear();
                DataGrid DataGrid = sender as DataGrid;
                texi11.Text = "";
                ks = 0;
                t2 = 0;
                kv = 0;
                selectedindexszam = 0;
                selectedindexszam = DataGrid.SelectedIndex + 1;
                var tagok = File.ReadAllLines(@"tagok.txt");
                var kolcsonzesek = File.ReadAllLines(@"kolcsonzesek.txt");
                var konyvek = File.ReadAllLines(@"konyvek.txt");

                if ((DataGrid.Items.Count > 0) && (DataGrid.SelectedIndex > -1) && (DataGrid.SelectedItem != null))
                {
                    foreach (var item in tagok)
                    {
                        List<string> tagoklist = tagok[t2].Split(';').ToList();
                        if (Convert.ToString(selectedindexszam) == tagoklist[0])
                        {
                            Neve.Text = tagoklist[1];                        
                        }
                        t2++;        
                    }              
                    foreach (var item in kolcsonzesek)
                    {
                        List<string> kolcsonzeseklist = kolcsonzesek[ks].Split(';').ToList();
                        if (Convert.ToString(selectedindexszam) == kolcsonzeseklist[1])
                        {
                            Száma.Text = Convert.ToString(selectedindexszam);
                            texi11.Text += "Kölcsönzésszám: " + kolcsonzeseklist[0] + ";   ";
                            texi11.Text += "Könyv szám: " + kolcsonzeseklist[2] + ";   ";
                            Könyvek.Text += kolcsonzeseklist[2] + "\n";
                            vegyeslist.Add(kolcsonzeseklist[2]);
                            texi11.Text += "Kölcsönzési dátum: " + kolcsonzeseklist[3] + ";   ";
                            texi11.Text += "Visszavételi dátum: " + kolcsonzeseklist[4] + "; \n";
                        }
                        ks++;
                    }
                    texi11.Text += "\n";
                    texi11.Text += "\n";
                    int f = 0;
                    Kikölcsönzöttkönyvekszama.Text = Convert.ToString(Könyvek.LineCount - 1);

                    int number = 0;
                    number = Convert.ToInt32(Kikölcsönzöttkönyvekszama.Text);
                    foreach (var item in konyvek)
                    {
                        List<string> konyveklist = konyvek[kv].Split(';').ToList();
                        for (int i = 0; i < number; i++)
                        {
                            if (Convert.ToInt32(vegyeslist[i]) == Convert.ToInt32(konyveklist[0]))
                            {
                                texi11.Text += "Száma: " + vegyeslist[i] + ";   ";
                                texi11.Text += "Szerző: " + konyveklist[1] + ";   ";
                                texi11.Text += "Címe: " + konyveklist[2] + ";   ";
                                texi11.Text += "Kiadás: " + konyveklist[3] + ";   ";
                                texi11.Text += "Kiadó: " + konyveklist[4] + "; \n";
                            }
                        }
                        kv = kv + 1;
                    }
                }
            }
            catch { }
        }
        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(txtFilter.Text))
                return true;
            else
                return ((item as Patient).Name.IndexOf(txtFilter.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }
        private void txtFilter_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(dgUsers.ItemsSource).Refresh();
        }

        private void Addrow_Click(object sender, RoutedEventArgs e)
        {
           
            using (StreamWriter writer = new StreamWriter("tagok.txt"))             //ez elmenti a fájlba a sorokat
            {
                foreach (Patient patient in this._list)
                {
                    writer.WriteLine(patient.GetLine());
                }
            }

            string path = @"tagok.txt";     
            using (StreamWriter sw = File.AppendText(path)) //üres sort
            {
                sw.WriteLine("000;valami;valami;0;valami;valami", Encoding.Unicode);     
            }
        }
    }
   
    class Patient
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Szül { get; set; }
        public int IrSz { get; set; }
        public string Település { get; set; }
        public string Cím { get; set; }
        public Patient(string line)
        {
            string[] parts = line.Split(';');
            this.Id = parts[0];
            this.Name = parts[1];
            this.Szül = parts[2];
            this.IrSz = int.Parse(parts[3]);
            this.Település = parts[4];
            this.Cím = parts[5];
        }
        public string GetLine()
        {
            return this.Id + ";" + this.Name + ";" + this.Szül + ";" + this.IrSz + ";" + this.Település + ";" + this.Cím + ";"     .ToString();
        }
   
    }
}